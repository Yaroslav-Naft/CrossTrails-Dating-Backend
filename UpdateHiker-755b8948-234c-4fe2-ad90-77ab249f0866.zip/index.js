const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });

exports.handler = async event => {
    const params = {
        TableName: "Hikers",
        Key: {
            "hikersId": event.hikers.hikersId
        },
        UpdateExpression: "set age = :ag, firstName = :fn, lastName =:ln,favouritesHikes =:fh, imageUrl = :tt, gender = :gg",
        ExpressionAttributeValues: {
             ':ag': event.hikers.age,
             ':fn': event.hikers.firstName,
             ':ln': event.hikers.lastName,
             ':fh': event.hikers.favouritesHikes,
             ':tt': event.hikers.imageUrl,
             ':gg': event.hikers.gender,           
        },
    }
        // const response = {
        //     headers:{ 'Access-Control-Allow-Origin' : '*' },
        //     body: JSON.stringify(event),
        //     statusCode: 200
        // };
        // return response;
        
        
        
    try {
        const data = await docClient.update(params).promise();
        const response = {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            statusCode: 200
        };
        return response;
    } catch (err) {
        return {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            statusCode: 500
        };
    }
};