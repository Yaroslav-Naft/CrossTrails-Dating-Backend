const AWS = require("aws-sdk");
const cognito = new AWS.CognitoIdentityServiceProvider({ region: 'us-west-1' })
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });


exports.handler = async (event, context) => {
        
    const parameters = {
        TableName: "Likes",
        FilterExpression: 'LikesId = :likesId',
        ExpressionAttributeValues: {
          ":likesId": event.likesId
        }
    };
    
    //   const response1 = {
    //         statusCode: 200,
    //         body: JSON.stringify(event.likesId),
    //         headers:{ 'Access-Control-Allow-Origin' : '*' }
    //     };
    //     return response1;
    

    try {
    const scanData = await docClient.scan(parameters).promise();
        
        // const response1 = {
        //     statusCode: 200,
        //     body: JSON.stringify(scanData),
        //     headers:{ 'Access-Control-Allow-Origin' : '*' }
        // };
        // return response1;


    //     const parameters = {
    //     TableName: "Hikers",
    //     FilterExpression: 'userName = :userName',
    //     ExpressionAttributeValues: {
    //       ":userName": "yaronaftulyev"
    //     }
    // };
    
      var params = {
        TableName: "Hikers",
        Key: {
            hikersId: scanData.Items[0].hikersId
        }
      }
        
    const data = await docClient.delete(params).promise();
        const response = {
            statusCode: 200,
            body: JSON.stringify(data.Item),
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
        return response;
    } catch (err) {
            return {
            statusCode: 500,
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
    }
};

