const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });

exports.handler = async event => {
    const params = {
        TableName: "Hikers",
        FilterExpression: 'userName = :userName',
        ExpressionAttributeValues: {
          ":userName": event.pathParameters.userName
        }
    };

    try {
        const data = await docClient.scan(params).promise();
        //const data = await docClient.get(params).promise();
        
        const response = {
                statusCode: 200,
                body: JSON.stringify(data.Items),
                headers:{ 'Access-Control-Allow-Origin' : '*' }
            };

        return response;
    } catch (err) {
        return {
            statusCode: 500
        };
    }
};




//     const AWS = require("aws-sdk");

//     const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });

//     exports.handler = async event => {
//     const params = {
//         TableName: "Products"
//     };

//     try {
//         //await to satisfy the promise
//         const data = await docClient.scan(params).promise();
//         //the response is now a JSON object with a status code of 200 and a body of JSON data
//         const response = {
//             statusCode: 200,
//             body: JSON.stringify(data.Items)
//         };
//         // Return the JSON response
//         return response;
//         //if there is an error we won't return any body, but just a status code of 500 to indicate a failed attempt
//         } catch (e) {
//         return {
//             statusCode: 500
//         };
//     }
// };