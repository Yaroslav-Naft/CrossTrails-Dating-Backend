const AWS = require("aws-sdk");
const cognito = new AWS.CognitoIdentityServiceProvider({ region: 'us-west-1' })
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });


exports.handler = async (event, context) => {
        
    const parameters = {
        TableName: "Likes",
        FilterExpression: 'TargetUserName = :userName',
        ExpressionAttributeValues: {
          ":userName": event.pathParameters.userName
        }
    };

    try {
    const scanData = await docClient.scan(parameters).promise();
        
        const response = {
            statusCode: 200,
            body: JSON.stringify(scanData.Items),
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
        return response;
    } catch (err) {
            return {
            statusCode: 500,
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
    }
};

