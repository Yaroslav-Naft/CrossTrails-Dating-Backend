const AWS = require("aws-sdk");
const cognito = new AWS.CognitoIdentityServiceProvider({ region: 'us-west-1' })
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });


exports.handler = async (event, context) => {
        
    const parameters = {
        TableName: "Hikers",
        FilterExpression: 'userName = :userName',
        ExpressionAttributeValues: {
          ":userName": event.pathParameters.userName
        }
    };

    try {
    const scanData = await docClient.scan(parameters).promise();
        
    const newdata = await new Promise((resolve, reject) => {
    const params = {
      UserPoolId: 'us-west-1_VJM6VrFOb',
      Username: event.pathParameters.userName
    }

    cognito.adminDeleteUser(params, (err, data) => {
      if (err) {
        reject(err)
      } else {
        resolve(data)
      }
    })
  })

        
    //     const parameters = {
    //     TableName: "Hikers",
    //     FilterExpression: 'userName = :userName',
    //     ExpressionAttributeValues: {
    //       ":userName": "yaronaftulyev"
    //     }
    // };
    
      var params = {
        TableName: "Hikers",
        Key: {
            hikersId: scanData.Items[0].hikersId
        }
      }
        
    const data = await docClient.delete(params).promise();
        const response = {
            statusCode: 200,
            body: JSON.stringify(data.Item),
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
        return response;
    } catch (err) {
            return {
            statusCode: 500,
            headers:{ 'Access-Control-Allow-Origin' : '*' }
        };
    }
};

