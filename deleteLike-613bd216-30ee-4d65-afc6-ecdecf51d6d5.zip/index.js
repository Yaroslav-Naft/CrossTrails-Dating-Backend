const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });



exports.handler = async (event) => {
    const params = {
        TableName: "Likes",
        Key: {
            LikesId: event.pathParameters.likesId
        }
    };
    
    
    try {
        const data = await docClient.delete(params).promise();
        const response = {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            body: JSON.stringify(params),
            statusCode: 200
        };
        return response;
    } catch (err) {
        return {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            body: JSON.stringify(err),
            statusCode: 500
        };
    }
    
};