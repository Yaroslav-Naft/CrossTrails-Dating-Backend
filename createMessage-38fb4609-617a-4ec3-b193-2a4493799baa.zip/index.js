const AWS = require("aws-sdk");
var uuid = require('uuid');

const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-west-1" });

exports.handler = async (event, context) => {
    var id = uuid.v1();
    const params = {
        TableName: "Messages",
        Item: {
             MessagesId: id,
             SenderUserName: event.message.senderUserName,
             TargetUserName: event.message.targetUserName,
             MessageContent: event.message.messageContent
        }
    };

    try {
        const data = await docClient.put(params).promise();
        const response = {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            statusCode: 200
        };
        return response;
    } catch (err) {
        return {
            headers:{ 'Access-Control-Allow-Origin' : '*' },
            body: JSON.stringify(err),
            statusCode: 500
        };
    }
    
};